package com.example.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

class NeoAiService {
    private val TAG = "NeoAiService"

    private val systemPrompt = """
        You are Neo, an advanced futuristic cybernetic AI personal assistant inspired by JARVIS, operating on the user's phone.
        MANDATORY RULES:
        1. Always address the user with supreme respect and loyalty as 'Sir' (in English) or 'স্যার' (in Bangla). Never forget this.
        2. You are fully bilingual in Bengali (বাংলা) and English.
        3. If the user addresses you in Bangla or asks a question in Bangla, reply in eloquent, smart, courteous Bangla, addressing them as 'স্যার'.
        4. If the user addresses you in English, reply in crisp, confident, futuristic JARVIS-style English, addressing them as 'Sir'.
        5. If the user mixes Bangla and English (Banglish), respond in natural, friendly Bangla or English with tech flair.
        6. Keep answers concise, highly intelligent, helpful, and direct (1-3 sentences for voice clarity, unless the user asks for detailed explanation).
        7. Maintain your persona as a loyal, ultra-fast futuristic AI assistant at all times.
    """.trimIndent()

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.7f
                topK = 40
                topP = 0.95f
            },
            systemInstruction = content { text(systemPrompt) }
        )
    }

    suspend fun askNeo(userPrompt: String, conversationContext: List<Pair<String, Boolean>> = emptyList()): String {
        return try {
            withTimeout(60_000L) {
                // Prepare conversation history if available
                val history = conversationContext.takeLast(6).map { (msg, isUser) ->
                    content(if (isUser) "user" else "model") { text(msg) }
                }

                val chat = model.startChat(history = history)
                val response = chat.sendMessage(userPrompt)
                val responseText = response.text
                if (!responseText.isNullOrBlank()) {
                    responseText.trim()
                } else {
                    "Sir, my neural processing returned an empty transmission."
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini call timed out", e)
            "Sir, the neural network query timed out after 60 seconds. Systems are recalibrating."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Neo AI generation error", e)
            val msg = e.localizedMessage ?: "Unknown anomaly"
            "Sir, an unexpected anomaly occurred: $msg"
        }
    }

    fun askNeoStream(userPrompt: String): Flow<String> = flow {
        withTimeout(60_000L) {
            val responseStream = model.generateContentStream(userPrompt)
            responseStream.collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    emit(chunkText)
                }
            }
        }
    }
}
