package com.example.command

import com.example.device.NeoDeviceController

sealed interface ParsedCommand {
    data class DeviceAction(val result: NeoDeviceController.ActionResult, val commandName: String) : ParsedCommand
    data class CallAction(val target: String) : ParsedCommand
    data class GeneralQuery(val query: String) : ParsedCommand
}

class NeoCommandParser(private val deviceController: NeoDeviceController) {

    fun parse(input: String): ParsedCommand {
        val text = input.trim().lowercase()

        // 1. Flashlight / Torch
        if (matchesAny(text, "flashlight on", "torch on", "turn on light", "turn on flash", "turn on flashlight", "লাইট অন", "টর্চ অন", "টর্চ জ্বালাও", "ফ্ল্যাশলাইট জ্বালাও", "ফ্ল্যাশ অন")) {
            val res = deviceController.toggleFlashlight(forceState = true)
            return ParsedCommand.DeviceAction(res, "Flashlight On")
        }
        if (matchesAny(text, "flashlight off", "torch off", "turn off light", "turn off flash", "turn off flashlight", "লাইট অফ", "টর্চ অফ", "টর্চ বন্ধ", "ফ্ল্যাশলাইট বন্ধ", "ফ্ল্যাশ অফ")) {
            val res = deviceController.toggleFlashlight(forceState = false)
            return ParsedCommand.DeviceAction(res, "Flashlight Off")
        }
        if (matchesAny(text, "flashlight", "torch", "টর্চ", "ফ্ল্যাশলাইট")) {
            val res = deviceController.toggleFlashlight()
            return ParsedCommand.DeviceAction(res, "Toggle Flashlight")
        }

        // 2. Camera
        if (matchesAny(text, "open camera", "launch camera", "take photo", "start camera", "ক্যামেরা খোলো", "ক্যামেরা অন", "ছবি তুলব", "ক্যামেরা চালু করো")) {
            val res = deviceController.openCamera()
            return ParsedCommand.DeviceAction(res, "Open Camera")
        }

        // 3. Phone Call
        val callRegex = Regex("(?:call|dial|phone|কল করো|ফোন দাও|কল দাও)\\s+(.*)", RegexOption.IGNORE_CASE)
        val callMatch = callRegex.find(text)
        if (callMatch != null) {
            val target = callMatch.groupValues[1].trim()
            if (target.isNotBlank()) {
                val digitsOnly = target.replace(Regex("[^0-9+]"), "")
                if (digitsOnly.length >= 3) {
                    val res = deviceController.makeCall(digitsOnly)
                    return ParsedCommand.DeviceAction(res, "Call $digitsOnly")
                } else {
                    return ParsedCommand.CallAction(target)
                }
            }
        }

        // 4. Alarm
        if (text.contains("alarm") || text.contains("অ্যালার্ম")) {
            // Extract hour and minute if present
            val timeRegex = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?")
            val m = timeRegex.find(text)
            if (m != null) {
                var hour = m.groupValues[1].toIntOrNull() ?: 7
                val minute = m.groupValues[2].toIntOrNull() ?: 0
                val amPm = m.groupValues[3].lowercase()
                if (amPm == "pm" && hour < 12) hour += 12
                if (amPm == "am" && hour == 12) hour = 0
                val res = deviceController.setAlarm(hour, minute)
                return ParsedCommand.DeviceAction(res, "Set Alarm")
            } else {
                val res = deviceController.setAlarm(7, 0)
                return ParsedCommand.DeviceAction(res, "Set Default Alarm")
            }
        }

        // 5. Timer
        if (text.contains("timer") || text.contains("টাইমার")) {
            val numRegex = Regex("(\\d+)\\s*(minute|min|sec|second|মিনিট|সেকেন্ড)?")
            val m = numRegex.find(text)
            val count = m?.groupValues?.get(1)?.toIntOrNull() ?: 5
            val unit = m?.groupValues?.getOrNull(2) ?: ""
            val seconds = if (unit.contains("sec") || unit.contains("সেকেন্ড")) count else count * 60
            val res = deviceController.setTimer(seconds)
            return ParsedCommand.DeviceAction(res, "Set Timer")
        }

        // 6. YouTube
        if (text.contains("youtube") || text.contains("ইউটিউব")) {
            val query = text.replace(Regex("^(open|play|launch|search|on|ইউটিউব|ইউটিউবে|খোলো|চালু করো|সার্চ করো|গান)\\s*"), "").trim()
            val res = deviceController.openYouTube(if (query.isNotBlank() && query != "youtube" && query != "ইউটিউব") query else null)
            return ParsedCommand.DeviceAction(res, "YouTube")
        }

        // 7. Google Maps / Navigation
        if (text.contains("map") || text.contains("maps") || text.contains("ম্যাপ") || text.contains("রাস্তা") || text.contains("navigate") || text.contains("direction")) {
            val query = text.replace(Regex("^(open|launch|show|navigate to|directions to|ম্যাপ|ম্যাপস|খোলো|দেখাও|যাব)\\s*"), "").trim()
            val res = deviceController.openMaps(if (query.isNotBlank() && !query.contains("map")) query else null)
            return ParsedCommand.DeviceAction(res, "Maps Navigation")
        }

        // 8. Battery Status
        if (matchesAny(text, "battery", "battery status", "charge", "battery level", "ব্যাটারি", "চার্জ কত", "ব্যাটারি কত", "চার্জিং")) {
            val batteryMsg = deviceController.getBatteryStatus()
            val res = NeoDeviceController.ActionResult(
                isHandled = true,
                feedbackBangla = batteryMsg,
                feedbackEnglish = "Battery level verified, Sir. All power cells operating normally."
            )
            return ParsedCommand.DeviceAction(res, "Battery Telemetry")
        }

        // 9. Open specific apps
        val appMatches = listOf("whatsapp", "facebook", "chrome", "calculator", "settings", "clock", "calendar", "gmail", "telegram")
        for (app in appMatches) {
            if (text.contains(app)) {
                val res = deviceController.openApp(app)
                return ParsedCommand.DeviceAction(res, "Open $app")
            }
        }

        // Otherwise pass to Gemini AI Core
        return ParsedCommand.GeneralQuery(input)
    }

    private fun matchesAny(text: String, vararg patterns: String): Boolean {
        return patterns.any { text.contains(it) }
    }
}
