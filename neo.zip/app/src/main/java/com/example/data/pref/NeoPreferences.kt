package com.example.data.pref

import android.content.Context
import android.content.SharedPreferences

class NeoPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("neo_assistant_prefs", Context.MODE_PRIVATE)

    var preferredLanguage: String
        get() = prefs.getString(KEY_LANGUAGE, "auto") ?: "auto" // "auto", "bn", "en"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var userHonorific: String
        get() = prefs.getString(KEY_HONORIFIC, "Sir") ?: "Sir"
        set(value) = prefs.edit().putString(KEY_HONORIFIC, value).apply()

    var speechRate: Float
        get() = prefs.getFloat(KEY_SPEECH_RATE, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_RATE, value).apply()

    var speechPitch: Float
        get() = prefs.getFloat(KEY_SPEECH_PITCH, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_PITCH, value).apply()

    var autoSpeakResponses: Boolean
        get() = prefs.getBoolean(KEY_AUTO_SPEAK, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_SPEAK, value).apply()

    var autoListenAfterReply: Boolean
        get() = prefs.getBoolean(KEY_AUTO_LISTEN, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_LISTEN, value).apply()

    var foregroundServiceEnabled: Boolean
        get() = prefs.getBoolean(KEY_FG_SERVICE, true)
        set(value) = prefs.edit().putBoolean(KEY_FG_SERVICE, value).apply()

    var hapticFeedbackEnabled: Boolean
        get() = prefs.getBoolean(KEY_HAPTIC, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTIC, value).apply()

    companion object {
        private const val KEY_LANGUAGE = "key_preferred_language"
        private const val KEY_HONORIFIC = "key_user_honorific"
        private const val KEY_SPEECH_RATE = "key_speech_rate"
        private const val KEY_SPEECH_PITCH = "key_speech_pitch"
        private const val KEY_AUTO_SPEAK = "key_auto_speak"
        private const val KEY_AUTO_LISTEN = "key_auto_listen"
        private const val KEY_FG_SERVICE = "key_foreground_service"
        private const val KEY_HAPTIC = "key_haptic_feedback"
    }
}
