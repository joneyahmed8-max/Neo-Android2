package com.example.device

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.ContextCompat

class NeoDeviceController(private val context: Context) {
    private val TAG = "NeoDeviceController"
    private var isTorchOn = false

    data class ActionResult(
        val isHandled: Boolean,
        val feedbackBangla: String,
        val feedbackEnglish: String,
        val openIntent: Intent? = null
    )

    fun toggleFlashlight(forceState: Boolean? = null): ActionResult {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return ActionResult(false, "ফ্ল্যাশলাইট কন্ট্রোলার পাওয়া যায়নি, স্যার।", "Camera manager unavailable, Sir.")
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult(false, "এই ডিভাইসে ফ্ল্যাশলাইট পাওয়া যায়নি, স্যার।", "No hardware flash found, Sir.")

            val targetState = forceState ?: !isTorchOn
            cameraManager.setTorchMode(cameraId, targetState)
            isTorchOn = targetState

            val stateBn = if (isTorchOn) "চালু করেছি" else "বন্ধ করেছি"
            val stateEn = if (isTorchOn) "enabled" else "disabled"
            return ActionResult(
                true,
                "ফ্ল্যাশলাইট $stateBn, স্যার।",
                "Flashlight has been $stateEn, Sir."
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle flashlight", e)
            return ActionResult(false, "ফ্ল্যাশলাইট কন্ট্রোল ব্যর্থ হয়েছে, স্যার: ${e.message}", "Flashlight control failed, Sir: ${e.message}")
        }
    }

    fun isFlashlightOn(): Boolean = isTorchOn

    fun makeCall(phoneNumber: String, useDirectCall: Boolean = false): ActionResult {
        val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
        if (cleanNumber.isBlank()) {
            return ActionResult(false, "সঠিক ফোন নম্বর পাওয়া যায়নি, স্যার।", "Invalid phone number provided, Sir.")
        }

        return try {
            val intentAction = if (useDirectCall && ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.CALL_PHONE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                Intent.ACTION_CALL
            } else {
                Intent.ACTION_DIAL
            }

            val intent = Intent(intentAction).apply {
                data = Uri.parse("tel:$cleanNumber")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(
                true,
                "$cleanNumber নম্বরে কল সংযুক্ত করছি, স্যার।",
                "Initiating call to $cleanNumber, Sir.",
                intent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Call execution error", e)
            ActionResult(false, "কল সংযোগ ব্যর্থ হয়েছে, স্যার।", "Call initiation failed, Sir.")
        }
    }

    fun openCamera(): ActionResult {
        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "ক্যামেরা ওপেন করছি, স্যার।", "Launching optical sensors, Sir.", intent)
        } catch (e: Exception) {
            try {
                val fallback = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallback)
                ActionResult(true, "ক্যামেরা ওপেন করছি, স্যার।", "Launching optical sensors, Sir.", fallback)
            } catch (ex: Exception) {
                Log.e(TAG, "Camera open failed", ex)
                ActionResult(false, "ক্যামেরা চালু করা সম্ভব হয়নি, স্যার।", "Unable to launch camera, Sir.")
            }
        }
    }

    fun setAlarm(hour: Int, minutes: Int, message: String = "Neo Alarm"): ActionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            val timeStr = String.format("%02d:%02d", hour, minutes)
            ActionResult(
                true,
                "সময় $timeStr এর জন্য অ্যালার্ম সেট করা হয়েছে, স্যার।",
                "Alarm programmed for $timeStr, Sir.",
                intent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Alarm error", e)
            ActionResult(false, "অ্যালার্ম সেট করা সম্ভব হয়নি, স্যার।", "Alarm setup failed, Sir.")
        }
    }

    fun setTimer(seconds: Int, message: String = "Neo Timer"): ActionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            val min = seconds / 60
            val sec = seconds % 60
            ActionResult(
                true,
                "$min মিনিট $sec সেকেন্ডের টাইমার সেট করা হয়েছে, স্যার।",
                "Timer set for $min minutes and $sec seconds, Sir.",
                intent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Timer error", e)
            ActionResult(false, "টাইমার সেট করা সম্ভব হয়নি, স্যার।", "Timer setup failed, Sir.")
        }
    }

    fun openYouTube(query: String? = null): ActionResult {
        return try {
            val intent = if (!query.isNullOrBlank()) {
                Intent(Intent.ACTION_SEARCH).apply {
                    setPackage("com.google.android.youtube")
                    putExtra("query", query)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } else {
                context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            }.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            val qTextBn = if (query != null) "'$query' খুঁজছি" else "ওপেন করছি"
            val qTextEn = if (query != null) "searching for '$query'" else "launched"
            ActionResult(true, "ইউটিউব $qTextBn, স্যার।", "YouTube $qTextEn, Sir.", intent)
        } catch (e: Exception) {
            // Web fallback
            val webIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse(if (query.isNullOrBlank()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            context.startActivity(webIntent)
            ActionResult(true, "ব্রাউজারে ইউটিউব ওপেন করছি, স্যার।", "Opening YouTube in browser, Sir.", webIntent)
        }
    }

    fun openMaps(locationQuery: String? = null): ActionResult {
        return try {
            val uri = if (!locationQuery.isNullOrBlank()) {
                Uri.parse("geo:0,0?q=${Uri.encode(locationQuery)}")
            } else {
                Uri.parse("geo:0,0?q=")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            val locBn = if (!locationQuery.isNullOrBlank()) "'$locationQuery' এর ম্যাপ" else "গুগল ম্যাপস"
            val locEn = if (!locationQuery.isNullOrBlank()) "maps for '$locationQuery'" else "Google Maps"
            ActionResult(true, "$locBn ওপেন করছি, স্যার।", "Plotting $locEn on navigation systems, Sir.", intent)
        } catch (e: Exception) {
            val webIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(locationQuery ?: "")}")
            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            context.startActivity(webIntent)
            ActionResult(true, "ব্রাউজারে ম্যাপ ওপেন করছি, স্যার।", "Opening maps via web, Sir.", webIntent)
        }
    }

    fun openApp(appName: String): ActionResult {
        val pm = context.packageManager
        val cleanName = appName.lowercase().trim()

        val packageMap = mapOf(
            "whatsapp" to "com.whatsapp",
            "facebook" to "com.facebook.katana",
            "chrome" to "com.android.chrome",
            "calculator" to listOf("com.google.android.calculator", "com.android.calculator2", "com.transsion.calculator"),
            "settings" to "com.android.settings",
            "clock" to listOf("com.google.android.deskclock", "com.android.deskclock"),
            "calendar" to listOf("com.google.android.calendar", "com.android.calendar"),
            "gmail" to "com.google.android.gm",
            "gallery" to listOf("com.google.android.apps.photos", "com.android.gallery3d"),
            "play store" to "com.android.vending",
            "telegram" to "org.telegram.messenger"
        )

        for ((key, pkgOrList) in packageMap) {
            if (cleanName.contains(key)) {
                if (pkgOrList is String) {
                    val launchIntent = pm.getLaunchIntentForPackage(pkgOrList)
                    if (launchIntent != null) {
                        launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        context.startActivity(launchIntent)
                        return ActionResult(true, "$key অ্যাপ চালু করছি, স্যার।", "Launching $key, Sir.", launchIntent)
                    }
                } else if (pkgOrList is List<*>) {
                    for (pkg in pkgOrList) {
                        val launchIntent = pm.getLaunchIntentForPackage(pkg as String)
                        if (launchIntent != null) {
                            launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            context.startActivity(launchIntent)
                            return ActionResult(true, "$key অ্যাপ চালু করছি, স্যার।", "Launching $key, Sir.", launchIntent)
                        }
                    }
                }
            }
        }

        // Search installed apps by label
        try {
            val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (appInfo in installedApps) {
                val appLabel = pm.getApplicationLabel(appInfo).toString().lowercase()
                if (appLabel.contains(cleanName) || cleanName.contains(appLabel)) {
                    val intent = pm.getLaunchIntentForPackage(appInfo.packageName)
                    if (intent != null) {
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        context.startActivity(intent)
                        return ActionResult(true, "$appLabel চালু করছি, স্যার।", "Launching $appLabel, Sir.", intent)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed searching apps", e)
        }

        return ActionResult(false, "'$appName' অ্যাপটি ডিভাইসে খুঁজে পাওয়া যায়নি, স্যার।", "Unable to locate '$appName' on your device, Sir.")
    }

    fun getBatteryStatus(): String {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            if (level >= 0) {
                "ব্যাটারি লেভেল $level শতাংশ, স্যার। সমস্ত সিস্টেম সক্রিয় রয়েছে।"
            } else {
                "ব্যাটারি স্ট্যাটাস রেডি, স্যার।"
            }
        } catch (e: Exception) {
            "ব্যাটারি ইনফো সংগৃহীত, স্যার।"
        }
    }
}
