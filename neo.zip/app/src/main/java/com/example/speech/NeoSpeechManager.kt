package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class NeoSpeechManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit
) : RecognitionListener, TextToSpeech.OnInitListener {

    private val TAG = "NeoSpeechManager"

    sealed interface SpeechState {
        data object Idle : SpeechState
        data class Listening(val rmsDb: Float) : SpeechState
        data class Speaking(val text: String) : SpeechState
        data class Error(val message: String) : SpeechState
    }

    private val _speechState = MutableStateFlow<SpeechState>(SpeechState.Idle)
    val speechState: StateFlow<SpeechState> = _speechState.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    var speechRate: Float = 1.0f
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    var speechPitch: Float = 1.0f
        set(value) {
            field = value
            tts?.setPitch(value)
        }

    init {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(this@NeoSpeechManager)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "SpeechRecognizer initialization failed", e)
        }

        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            tts?.let { engine ->
                engine.setSpeechRate(speechRate)
                engine.setPitch(speechPitch)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        // Utterance started
                    }

                    override fun onDone(utteranceId: String?) {
                        if (_speechState.value is SpeechState.Speaking) {
                            _speechState.value = SpeechState.Idle
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (_speechState.value is SpeechState.Speaking) {
                            _speechState.value = SpeechState.Idle
                        }
                    }
                })
            }
            Log.d(TAG, "TextToSpeech initialized successfully.")
        } else {
            Log.e(TAG, "TextToSpeech init failed with status: $status")
        }
    }

    fun startListening(languageCode: String = "auto") {
        stopSpeaking()
        if (speechRecognizer == null) {
            try {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(this@NeoSpeechManager)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Cannot create speech recognizer", e)
                _speechState.value = SpeechState.Error("ভয়েস রিকগনাইজার সক্রিয় করা যায়নি।")
                return
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

            when (languageCode) {
                "bn" -> {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("bn-BD", "en-US"))
                }
                "en" -> {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-US", "bn-BD"))
                }
                else -> {
                    // Auto / Multi-lingual support
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("bn-BD", "en-US"))
                }
            }
        }

        try {
            speechRecognizer?.startListening(intent)
            _speechState.value = SpeechState.Listening(0f)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting voice listening", e)
            _speechState.value = SpeechState.Error("ভয়েস শোনা শুরু করতে সমস্যা হয়েছে।")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping voice listening", e)
        }
        if (_speechState.value is SpeechState.Listening) {
            _speechState.value = SpeechState.Idle
        }
    }

    fun speak(text: String, preferBangla: Boolean? = null) {
        if (!isTtsReady || tts == null) {
            Log.w(TAG, "TTS not ready yet")
            return
        }

        stopListening()
        val cleanText = text.trim()
        if (cleanText.isBlank()) return

        // Detect if text contains Bengali Unicode characters (\u0980 to \u09FF)
        val hasBangla = cleanText.any { it in '\u0980'..'\u09FF' }
        val isBangla = preferBangla ?: hasBangla

        val selectedLocale = if (isBangla) {
            val bnBd = Locale("bn", "BD")
            val result = tts?.isLanguageAvailable(bnBd)
            if (result == TextToSpeech.LANG_AVAILABLE || result == TextToSpeech.LANG_COUNTRY_AVAILABLE) {
                bnBd
            } else {
                val bn = Locale("bn")
                val avail = tts?.isLanguageAvailable(bn) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (avail >= TextToSpeech.LANG_AVAILABLE) bn else Locale.US
            }
        } else {
            Locale.US
        }

        try {
            tts?.language = selectedLocale
            tts?.setSpeechRate(speechRate)
            tts?.setPitch(speechPitch)

            _speechState.value = SpeechState.Speaking(cleanText)
            val utteranceId = "neo_utterance_${System.currentTimeMillis()}"
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to speak text", e)
            _speechState.value = SpeechState.Idle
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping TTS", e)
        }
        if (_speechState.value is SpeechState.Speaking) {
            _speechState.value = SpeechState.Idle
        }
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying speech recognizer", e)
        }
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            Log.e(TAG, "Error shutting down TTS", e)
        }
    }

    // RecognitionListener Callbacks
    override fun onReadyForSpeech(params: Bundle?) {
        _speechState.value = SpeechState.Listening(0f)
    }

    override fun onBeginningOfSpeech() {}

    override fun onRmsChanged(rmsdB: Float) {
        if (_speechState.value is SpeechState.Listening) {
            _speechState.value = SpeechState.Listening(rmsdB.coerceAtLeast(0f))
        }
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        if (_speechState.value is SpeechState.Listening) {
            _speechState.value = SpeechState.Idle
        }
    }

    override fun onError(error: Int) {
        val errorMessage = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "কোনো কথা বুঝতে পারিনি, স্যার। আবার বলুন।"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কথা শনাক্তকরণ টাইমআউট হয়েছে।"
            SpeechRecognizer.ERROR_AUDIO -> "মাইক্রোফোন অডিও এরর।"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "নেটওয়ার্ক সংযোগ চেক করুন, স্যার।"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন পারমিশন প্রয়োজন।"
            else -> "ভয়েস শনাক্তকরণে সমস্যা হয়েছে (কোড $error)।"
        }
        Log.w(TAG, "SpeechRecognizer error: $error ($errorMessage)")
        _speechState.value = SpeechState.Error(errorMessage)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val recognizedText = matches?.firstOrNull()?.trim()
        if (!recognizedText.isNullOrBlank()) {
            _speechState.value = SpeechState.Idle
            onSpeechResult(recognizedText)
        } else {
            _speechState.value = SpeechState.Idle
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}

    override fun onEvent(eventType: Int, params: Bundle?) {}
}
