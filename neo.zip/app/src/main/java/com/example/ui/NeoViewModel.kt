package com.example.ui

import android.app.Application
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.NeoAiService
import com.example.command.NeoCommandParser
import com.example.command.ParsedCommand
import com.example.data.db.NeoDatabase
import com.example.data.model.ChatMessage
import com.example.data.pref.NeoPreferences
import com.example.device.NeoDeviceController
import com.example.service.NeoVoiceService
import com.example.speech.NeoSpeechManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AssistantStatus {
    STANDBY,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

data class NeoUiState(
    val status: AssistantStatus = AssistantStatus.STANDBY,
    val statusMessage: String = "STANDBY // READY FOR SIR'S COMMAND",
    val rmsDb: Float = 0f,
    val latestResponse: String = "Greetings, Sir. Neo neural core is online and ready for your command.",
    val latestUserQuery: String = "",
    val isFlashlightOn: Boolean = false,
    val errorMessage: String? = null,
    val selectedTab: Int = 0, // 0: HUD Core, 1: Chat Logs, 2: Actions, 3: Settings
    val preferBangla: Boolean = false,
    val isCallingContactPicker: Boolean = false
)

class NeoViewModel(application: Application) : AndroidViewModel(application) {

    private val TAG = "NeoViewModel"
    private val context = application.applicationContext

    val prefs = NeoPreferences(context)
    val deviceController = NeoDeviceController(context)
    private val commandParser = NeoCommandParser(deviceController)
    private val aiService = NeoAiService()
    private val db = NeoDatabase.getDatabase(context)
    val chatDao = db.chatDao()

    val chatMessages: StateFlow<List<ChatMessage>> = chatDao.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(NeoUiState())
    val uiState: StateFlow<NeoUiState> = _uiState.asStateFlow()

    private var speechManager: NeoSpeechManager? = null

    init {
        speechManager = NeoSpeechManager(context) { recognizedText ->
            handleUserInput(recognizedText)
        }

        // Apply saved speech rate and pitch
        speechManager?.speechRate = prefs.speechRate
        speechManager?.speechPitch = prefs.speechPitch

        // Observe speech manager state
        viewModelScope.launch {
            speechManager?.speechState?.collect { state ->
                when (state) {
                    is NeoSpeechManager.SpeechState.Idle -> {
                        if (_uiState.value.status == AssistantStatus.LISTENING || _uiState.value.status == AssistantStatus.SPEAKING) {
                            _uiState.value = _uiState.value.copy(
                                status = AssistantStatus.STANDBY,
                                statusMessage = "STANDBY // READY FOR COMMAND",
                                rmsDb = 0f
                            )
                        }
                    }
                    is NeoSpeechManager.SpeechState.Listening -> {
                        _uiState.value = _uiState.value.copy(
                            status = AssistantStatus.LISTENING,
                            statusMessage = "LISTENING TO SIR...",
                            rmsDb = state.rmsDb
                        )
                    }
                    is NeoSpeechManager.SpeechState.Speaking -> {
                        _uiState.value = _uiState.value.copy(
                            status = AssistantStatus.SPEAKING,
                            statusMessage = "TRANSMITTING RESPONSE...",
                            rmsDb = 0f
                        )
                    }
                    is NeoSpeechManager.SpeechState.Error -> {
                        _uiState.value = _uiState.value.copy(
                            status = AssistantStatus.ERROR,
                            statusMessage = state.message,
                            errorMessage = state.message,
                            rmsDb = 0f
                        )
                    }
                }
            }
        }

        // Start foreground service if enabled
        if (prefs.foregroundServiceEnabled) {
            try {
                NeoVoiceService.start(context)
            } catch (e: Exception) {
                Log.w(TAG, "Foreground service start deferred", e)
            }
        }
    }

    fun onVoiceButtonClick() {
        triggerHaptic()
        val currentStatus = _uiState.value.status
        if (currentStatus == AssistantStatus.SPEAKING) {
            stopSpeaking()
            return
        }
        if (currentStatus == AssistantStatus.LISTENING) {
            stopListening()
            return
        }

        startListening()
    }

    fun startListening() {
        _uiState.value = _uiState.value.copy(
            status = AssistantStatus.LISTENING,
            statusMessage = "LISTENING TO SIR...",
            errorMessage = null
        )
        val lang = prefs.preferredLanguage
        speechManager?.startListening(lang)
    }

    fun stopListening() {
        speechManager?.stopListening()
        _uiState.value = _uiState.value.copy(
            status = AssistantStatus.STANDBY,
            statusMessage = "STANDBY // READY FOR COMMAND",
            rmsDb = 0f
        )
    }

    fun handleUserInput(rawInput: String) {
        val input = rawInput.trim()
        if (input.isBlank()) return

        stopListening()
        _uiState.value = _uiState.value.copy(
            status = AssistantStatus.PROCESSING,
            statusMessage = "PROCESSING NEURAL QUERY...",
            latestUserQuery = input,
            errorMessage = null
        )

        viewModelScope.launch {
            // Save user message to DB
            val hasBangla = input.any { it in '\u0980'..'\u09FF' }
            val lang = if (hasBangla) "bn" else "en"
            chatDao.insertMessage(
                ChatMessage(
                    text = input,
                    isUser = true,
                    language = lang
                )
            )

            try {
                when (val parsed = commandParser.parse(input)) {
                    is ParsedCommand.DeviceAction -> {
                        val reply = if (hasBangla || prefs.preferredLanguage == "bn") {
                            parsed.result.feedbackBangla
                        } else {
                            parsed.result.feedbackEnglish
                        }

                        _uiState.value = _uiState.value.copy(
                            status = AssistantStatus.STANDBY,
                            statusMessage = "COMMAND EXECUTED",
                            latestResponse = reply,
                            isFlashlightOn = deviceController.isFlashlightOn()
                        )

                        chatDao.insertMessage(
                            ChatMessage(
                                text = reply,
                                isUser = false,
                                language = if (hasBangla) "bn" else "en",
                                actionCommand = parsed.commandName,
                                isSuccess = parsed.result.isHandled
                            )
                        )

                        if (prefs.autoSpeakResponses) {
                            speechManager?.speak(reply, preferBangla = hasBangla)
                        }
                    }

                    is ParsedCommand.CallAction -> {
                        val target = parsed.target
                        val reply = if (hasBangla) {
                            "কাকে কল করতে চান সিলেক্ট করুন অথবা সরাসরি ডায়াল করুন, স্যার।"
                        } else {
                            "Sir, please select contact for '$target' or dial directly."
                        }
                        _uiState.value = _uiState.value.copy(
                            status = AssistantStatus.STANDBY,
                            statusMessage = "READY FOR CALL",
                            latestResponse = reply,
                            isCallingContactPicker = true
                        )
                        chatDao.insertMessage(
                            ChatMessage(
                                text = reply,
                                isUser = false,
                                language = if (hasBangla) "bn" else "en",
                                actionCommand = "Call Picker"
                            )
                        )
                        if (prefs.autoSpeakResponses) {
                            speechManager?.speak(reply, preferBangla = hasBangla)
                        }
                    }

                    is ParsedCommand.GeneralQuery -> {
                        // Query Gemini AI Logic with recent conversation context
                        val recentMessages = chatDao.getRecentMessages(6).reversed()
                            .map { it.text to it.isUser }

                        val aiResponse = aiService.askNeo(input, recentMessages)
                        val replyHasBangla = aiResponse.any { it in '\u0980'..'\u09FF' }

                        _uiState.value = _uiState.value.copy(
                            status = AssistantStatus.STANDBY,
                            statusMessage = "TRANSMISSION COMPLETE",
                            latestResponse = aiResponse
                        )

                        chatDao.insertMessage(
                            ChatMessage(
                                text = aiResponse,
                                isUser = false,
                                language = if (replyHasBangla) "bn" else "en"
                            )
                        )

                        if (prefs.autoSpeakResponses) {
                            speechManager?.speak(aiResponse, preferBangla = replyHasBangla)
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error in handleUserInput", e)
                val err = "Sir, an unexpected anomaly occurred: ${e.message}"
                _uiState.value = _uiState.value.copy(
                    status = AssistantStatus.ERROR,
                    statusMessage = "ANOMALY ENCOUNTERED",
                    errorMessage = err,
                    latestResponse = err
                )
            }
        }
    }

    fun speak(text: String) {
        triggerHaptic()
        speechManager?.speak(text)
    }

    fun stopSpeaking() {
        speechManager?.stopSpeaking()
        _uiState.value = _uiState.value.copy(
            status = AssistantStatus.STANDBY,
            statusMessage = "VOICE TRANSMISSION HALTED"
        )
    }

    fun toggleFlashlight() {
        triggerHaptic()
        val result = deviceController.toggleFlashlight()
        val isBn = prefs.preferredLanguage == "bn"
        val feedback = if (isBn) result.feedbackBangla else result.feedbackEnglish
        _uiState.value = _uiState.value.copy(
            isFlashlightOn = deviceController.isFlashlightOn(),
            latestResponse = feedback
        )
        if (prefs.autoSpeakResponses) {
            speechManager?.speak(feedback, preferBangla = isBn)
        }
    }

    fun selectTab(tabIndex: Int) {
        triggerHaptic()
        _uiState.value = _uiState.value.copy(selectedTab = tabIndex)
    }

    fun clearChatHistory() {
        triggerHaptic()
        viewModelScope.launch {
            chatDao.clearAll()
            _uiState.value = _uiState.value.copy(
                latestResponse = "Memory logs flushed, Sir. Clean slate initialized."
            )
        }
    }

    fun updateLanguage(lang: String) {
        prefs.preferredLanguage = lang
        _uiState.value = _uiState.value.copy(preferBangla = lang == "bn")
    }

    fun updateSpeechRate(rate: Float) {
        prefs.speechRate = rate
        speechManager?.speechRate = rate
    }

    fun updateSpeechPitch(pitch: Float) {
        prefs.speechPitch = pitch
        speechManager?.speechPitch = pitch
    }

    fun toggleAutoSpeak(enabled: Boolean) {
        prefs.autoSpeakResponses = enabled
    }

    fun toggleForegroundService(enabled: Boolean) {
        prefs.foregroundServiceEnabled = enabled
        if (enabled) {
            NeoVoiceService.start(context)
        } else {
            NeoVoiceService.stop(context)
        }
    }

    private fun triggerHaptic() {
        if (!prefs.hapticFeedbackEnabled) return
        try {
            val vibrator = context.getSystemService(Application.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(30)
            }
        } catch (e: Exception) {
            // Non-fatal
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechManager?.destroy()
    }
}
