package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.ui.AssistantStatus
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramGlow
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NeoArcReactorLogo(
    status: AssistantStatus,
    rmsDb: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactorInfinite")

    // Rotation speeds based on status
    val baseDuration = when (status) {
        AssistantStatus.PROCESSING -> 1500
        AssistantStatus.LISTENING -> 3000
        AssistantStatus.SPEAKING -> 2500
        else -> 6000
    }

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(baseDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RotationAngle"
    )

    val counterRotationAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween((baseDuration * 1.5).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "CounterRotationAngle"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    // React to voice rmsDb
    val voiceScale = if (status == AssistantStatus.LISTENING) {
        (rmsDb / 15f).coerceIn(0f, 0.4f)
    } else 0f

    val totalScale = pulseScale + voiceScale

    Box(
        modifier = modifier.size(220.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f * 0.9f

            // 1. Ambient Background Radial Glow
            val glowBrush = Brush.radialGradient(
                colors = listOf(
                    NeonCyan.copy(alpha = if (status == AssistantStatus.PROCESSING) 0.35f else 0.18f),
                    ElectricBlue.copy(alpha = 0.08f),
                    Color.Transparent
                ),
                center = center,
                radius = maxRadius * totalScale
            )
            drawCircle(brush = glowBrush, radius = maxRadius * totalScale, center = center)

            // 2. Outer Static Tick Ring
            drawCircle(
                color = NeonBlue.copy(alpha = 0.25f),
                radius = maxRadius * 0.95f,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Outer Dashed Arc Segments
            rotate(rotationAngle, center) {
                for (i in 0 until 12) {
                    val angleDeg = i * 30.0
                    val angleRad = Math.toRadians(angleDeg)
                    val startR = maxRadius * 0.92f
                    val endR = maxRadius * 0.98f
                    val p1 = Offset(
                        center.x + (startR * cos(angleRad)).toFloat(),
                        center.y + (startR * sin(angleRad)).toFloat()
                    )
                    val p2 = Offset(
                        center.x + (endR * cos(angleRad)).toFloat(),
                        center.y + (endR * sin(angleRad)).toFloat()
                    )
                    drawLine(
                        color = if (i % 3 == 0) NeonCyan else HologramGlow.copy(alpha = 0.5f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 3 == 0) 3.dp.toPx() else 1.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }

                // Quad arcs
                drawArc(
                    color = NeonCyan,
                    startAngle = 10f,
                    sweepAngle = 70f,
                    useCenter = false,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
                drawArc(
                    color = NeonCyan,
                    startAngle = 190f,
                    sweepAngle = 70f,
                    useCenter = false,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // 3. Middle Counter-Rotating Circuit Ring
            rotate(counterRotationAngle, center) {
                drawCircle(
                    color = ElectricBlue.copy(alpha = 0.4f),
                    radius = maxRadius * 0.75f,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )

                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(NeonCyan, HologramGlow, ElectricBlue, NeonCyan),
                        center = center
                    ),
                    startAngle = 45f,
                    sweepAngle = 120f,
                    useCenter = false,
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(ElectricBlue, NeonCyan, HologramGlow, ElectricBlue),
                        center = center
                    ),
                    startAngle = 225f,
                    sweepAngle = 120f,
                    useCenter = false,
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // 4. Inner Reactor Core
            val coreRadius = maxRadius * 0.45f * totalScale
            val coreBrush = Brush.radialGradient(
                colors = listOf(
                    Color.White,
                    NeonCyan,
                    NeonBlue,
                    CyberBackground
                ),
                center = center,
                radius = coreRadius
            )
            drawCircle(brush = coreBrush, radius = coreRadius, center = center)

            // Inner Hexagonal / Star Nodes
            rotate(rotationAngle * 0.5f, center) {
                for (i in 0 until 6) {
                    val angle = Math.toRadians(i * 60.0)
                    val nodeR = coreRadius * 0.7f
                    val nodePos = Offset(
                        center.x + (nodeR * cos(angle)).toFloat(),
                        center.y + (nodeR * sin(angle)).toFloat()
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.5.dp.toPx(),
                        center = nodePos
                    )
                }
            }

            // Center Pure Energy Bead
            drawCircle(
                color = Color.White,
                radius = 6.dp.toPx(),
                center = center
            )
        }
    }
}
