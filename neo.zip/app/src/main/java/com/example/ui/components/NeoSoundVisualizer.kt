package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.example.ui.AssistantStatus
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramGlow
import com.example.ui.theme.NeonCyan

@Composable
fun NeoSoundVisualizer(
    status: AssistantStatus,
    rmsDb: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "Visualizer")

    val barCount = 19
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BarPulse"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val barGradients = Brush.verticalGradient(
            listOf(HologramGlow, NeonCyan, ElectricBlue)
        )

        for (i in 0 until barCount) {
            val centerDist = kotlin.math.abs(i - barCount / 2).toFloat()
            val baseFactor = (1f - (centerDist / (barCount / 2f)) * 0.6f).coerceIn(0.2f, 1f)

            val heightFactor = when (status) {
                AssistantStatus.LISTENING -> {
                    val voiceBoost = (rmsDb / 10f).coerceIn(0.2f, 1.8f)
                    val variance = (kotlin.math.sin(i * 0.8 + animProgress * 3.14) * 0.3).toFloat()
                    (baseFactor * voiceBoost + variance).coerceIn(0.15f, 1f)
                }
                AssistantStatus.SPEAKING -> {
                    val wave = (kotlin.math.sin(i * 0.6 + animProgress * 6.28) * 0.5 + 0.5).toFloat()
                    (baseFactor * wave).coerceIn(0.2f, 0.95f)
                }
                AssistantStatus.PROCESSING -> {
                    val pulse = (kotlin.math.cos(i * 0.4 + animProgress * 4.0) * 0.4 + 0.6).toFloat()
                    (baseFactor * pulse * 0.7f).coerceIn(0.2f, 0.8f)
                }
                else -> {
                    // STANDBY subtle breathing
                    (baseFactor * 0.2f).coerceIn(0.1f, 0.25f)
                }
            }

            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((40 * heightFactor).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(barGradients)
            )

            if (i < barCount - 1) {
                Box(modifier = Modifier.width(4.dp))
            }
        }
    }
}
