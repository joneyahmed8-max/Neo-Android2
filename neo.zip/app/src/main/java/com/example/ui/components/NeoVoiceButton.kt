package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.AssistantStatus
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramGlow
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan

@Composable
fun NeoVoiceButton(
    status: AssistantStatus,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "VoiceButtonAnim")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (status == AssistantStatus.LISTENING) 1.22f else 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                if (status == AssistantStatus.LISTENING) 700 else 1400,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    val ringAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RingAlpha"
    )

    Box(
        modifier = modifier.size(100.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing energy ring
        if (status == AssistantStatus.LISTENING || status == AssistantStatus.SPEAKING) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .scale(pulseScale)
                    .border(
                        width = 2.dp,
                        brush = Brush.radialGradient(
                            listOf(
                                HologramGlow.copy(alpha = ringAlpha),
                                NeonCyan.copy(alpha = ringAlpha * 0.5f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )
        }

        // Second subtle halo
        Box(
            modifier = Modifier
                .size(86.dp)
                .scale(if (status == AssistantStatus.LISTENING) pulseScale * 0.95f else 1f)
                .background(
                    brush = Brush.radialGradient(
                        listOf(
                            NeonCyan.copy(alpha = if (status == AssistantStatus.LISTENING) 0.35f else 0.15f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Main circular button
        val buttonGradient = when (status) {
            AssistantStatus.SPEAKING -> Brush.linearGradient(listOf(Color(0xFFFF1744), Color(0xFFD50000)))
            AssistantStatus.LISTENING -> Brush.linearGradient(listOf(NeonCyan, ElectricBlue))
            AssistantStatus.PROCESSING -> Brush.linearGradient(listOf(NeonBlue, HologramGlow))
            else -> Brush.linearGradient(listOf(CyberSurfaceVariant, CyberBackground))
        }

        val borderGradient = when (status) {
            AssistantStatus.SPEAKING -> Brush.linearGradient(listOf(Color(0xFFFF5252), Color(0xFFFF1744)))
            else -> Brush.linearGradient(listOf(NeonCyan, HologramGlow, ElectricBlue))
        }

        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(buttonGradient)
                .border(2.5.dp, borderGradient, CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = NeonCyan),
                    onClick = onClick
                )
                .testTag("voice_talk_button"),
            contentAlignment = Alignment.Center
        ) {
            val icon = if (status == AssistantStatus.SPEAKING) {
                Icons.Filled.Stop
            } else {
                Icons.Filled.Mic
            }

            val iconColor = if (status == AssistantStatus.STANDBY) NeonCyan else Color.White

            Icon(
                imageVector = icon,
                contentDescription = if (status == AssistantStatus.SPEAKING) "Stop Speaking" else "Tap to Speak",
                tint = iconColor,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}
