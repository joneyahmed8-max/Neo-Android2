package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary

@Composable
fun QuickActionGrid(
    isFlashlightOn: Boolean,
    preferBangla: Boolean,
    onToggleFlashlight: () -> Unit,
    onQuickAction: (String) -> Unit,
    onToggleLanguage: () -> Unit,
    onPickContact: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Flashlight Chip
        ActionChip(
            icon = if (isFlashlightOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
            label = if (isFlashlightOn) "টর্চ অন" else "টর্চ",
            tint = if (isFlashlightOn) CyberWarning else NeonCyan,
            isActive = isFlashlightOn,
            testTag = "chip_flashlight",
            onClick = onToggleFlashlight
        )

        // Camera Chip
        ActionChip(
            icon = Icons.Default.CameraAlt,
            label = if (preferBangla) "ক্যামেরা" else "Camera",
            tint = NeonBlue,
            testTag = "chip_camera",
            onClick = { onQuickAction("ক্যামেরা খোলো") }
        )

        // Call / Contact Chip
        ActionChip(
            icon = Icons.Default.Phone,
            label = if (preferBangla) "কল ডায়াল" else "Call",
            tint = CyberGreen,
            testTag = "chip_call",
            onClick = onPickContact
        )

        // YouTube Chip
        ActionChip(
            icon = Icons.Default.PlayArrow,
            label = "YouTube",
            tint = Color(0xFFFF3D00),
            testTag = "chip_youtube",
            onClick = { onQuickAction("open youtube") }
        )

        // Maps Chip
        ActionChip(
            icon = Icons.Default.Map,
            label = if (preferBangla) "ম্যাপস" else "Maps",
            tint = NeonCyan,
            testTag = "chip_maps",
            onClick = { onQuickAction("open maps") }
        )

        // Alarm Chip
        ActionChip(
            icon = Icons.Default.Alarm,
            label = if (preferBangla) "অ্যালার্ম" else "Alarm",
            tint = NeonBlue,
            testTag = "chip_alarm",
            onClick = { onQuickAction("set alarm for 7 am") }
        )

        // Battery Telemetry Chip
        ActionChip(
            icon = Icons.Default.BatteryFull,
            label = if (preferBangla) "ব্যাটারি" else "Battery",
            tint = CyberGreen,
            testTag = "chip_battery",
            onClick = { onQuickAction("battery status") }
        )

        // Language Switch Chip
        ActionChip(
            icon = Icons.Default.Translate,
            label = if (preferBangla) "বাংলা ✓" else "English ✓",
            tint = NeonCyan,
            testTag = "chip_lang",
            onClick = onToggleLanguage
        )
    }
}

@Composable
private fun ActionChip(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    testTag: String,
    isActive: Boolean = false
) {
    val borderColor = if (isActive) tint else CyberBorder
    val bg = if (isActive) tint.copy(alpha = 0.2f) else CyberSurface

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = tint),
                onClick = onClick
            )
            .testTag(testTag)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
