package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class CommandCategory(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val commands: List<Pair<String, String>> // English command to Bangla translation/description
)

@Composable
fun CommandsGuideScreen(
    onExecuteCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf(
        CommandCategory(
            title = "FLASHLIGHT / টর্চ কন্ট্রোল",
            icon = Icons.Default.FlashlightOn,
            color = CyberWarning,
            commands = listOf(
                "Turn on flashlight" to "টর্চ অন করো",
                "Turn off flashlight" to "টর্চ বন্ধ করো",
                "Toggle flashlight" to "ফ্ল্যাশলাইট জ্বালাও"
            )
        ),
        CommandCategory(
            title = "PHONE CALL / কলিং",
            icon = Icons.Default.Phone,
            color = CyberGreen,
            commands = listOf(
                "Call 999" to "৯৯৯ নম্বরে কল করো",
                "Dial phone number" to "ফোন নম্বর ডায়াল করো",
                "Call emergency" to "জরুরী নম্বরে কল দাও"
            )
        ),
        CommandCategory(
            title = "CAMERA / অপটিক্যাল সেন্সর",
            icon = Icons.Default.CameraAlt,
            color = NeonBlue,
            commands = listOf(
                "Open camera" to "ক্যামেরা খোলো",
                "Take a picture" to "ছবি তোলার ক্যামেরা অন করো"
            )
        ),
        CommandCategory(
            title = "YOUTUBE & MEDIA / ইউটিউব",
            icon = Icons.Default.PlayArrow,
            color = Color(0xFFFF3D00),
            commands = listOf(
                "Open YouTube" to "ইউটিউব ওপেন করো",
                "Search YouTube for science" to "ইউটিউবে সাইন্স ভিডিও দেখাও"
            )
        ),
        CommandCategory(
            title = "MAPS & NAVIGATION / ম্যাপস",
            icon = Icons.Default.Map,
            color = NeonCyan,
            commands = listOf(
                "Open Google Maps" to "গুগল ম্যাপস খোলো",
                "Navigate to Dhaka" to "ঢাকার ম্যাপ দেখাও"
            )
        ),
        CommandCategory(
            title = "ALARM & TIMER / অ্যালার্ম",
            icon = Icons.Default.Alarm,
            color = ElectricBlue,
            commands = listOf(
                "Set alarm for 7:00 AM" to "সকাল ৭টায় অ্যালার্ম সেট করো",
                "Set timer for 5 minutes" to "৫ মিনিটের টাইমার দাও"
            )
        ),
        CommandCategory(
            title = "APPS LAUNCHER / অ্যাপস",
            icon = Icons.Default.Smartphone,
            color = Color(0xFFAB47BC),
            commands = listOf(
                "Open WhatsApp" to "হোয়াটসঅ্যাপ খোলো",
                "Open Chrome" to "ক্রোম ব্রাউজার ওপেন করো",
                "Open Calculator" to "ক্যালকুলেটর খোলো",
                "Battery status" to "ব্যাটারি চার্জ কত আছে?"
            )
        ),
        CommandCategory(
            title = "GEMINI AI CHAT / কৃত্রিম বুদ্ধিমত্তা",
            icon = Icons.Default.Psychology,
            color = NeonCyan,
            commands = listOf(
                "Who are you, Neo?" to "তুমি কে নিও?",
                "What is the weather like?" to "আজকের আবহাওয়া কেমন, স্যার?",
                "Explain quantum physics in Bangla" to "কোয়ান্টাম ফিজিক্স সহজ করে বলো"
            )
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "NEO // COMMAND PROTOCOLS",
                color = NeonCyan,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Tap any protocol card to test voice execution immediately, Sir.",
                color = TextSecondary,
                fontSize = 11.sp
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(categories) { category ->
                CommandCategoryCard(category = category, onExecute = onExecuteCommand)
            }
        }
    }
}

@Composable
private fun CommandCategoryCard(
    category: CommandCategory,
    onExecute: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = category.icon,
                    contentDescription = category.title,
                    tint = category.color,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = category.title,
                    color = category.color,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                category.commands.forEach { (cmdEn, cmdBn) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBackground)
                            .border(1.dp, CyberBorder.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable { onExecute(cmdEn) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "\"$cmdEn\"",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = cmdBn,
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { onExecute(cmdEn) },
                            colors = ButtonDefaults.buttonColors(containerColor = category.color.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("execute_${cmdEn.take(10)}")
                        ) {
                            Text(
                                text = "Run",
                                color = category.color,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
