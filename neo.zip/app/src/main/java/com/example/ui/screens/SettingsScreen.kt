package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.NeoViewModel
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    viewModel: NeoViewModel,
    modifier: Modifier = Modifier
) {
    val prefs = viewModel.prefs
    val scrollState = rememberScrollState()

    var selectedLang by remember { mutableStateOf(prefs.preferredLanguage) }
    var speechRate by remember { mutableFloatStateOf(prefs.speechRate) }
    var speechPitch by remember { mutableFloatStateOf(prefs.speechPitch) }
    var autoSpeak by remember { mutableStateOf(prefs.autoSpeakResponses) }
    var foregroundService by remember { mutableStateOf(prefs.foregroundServiceEnabled) }
    var hapticFeedback by remember { mutableStateOf(prefs.hapticFeedbackEnabled) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "NEO // SYSTEM CONFIGURATION",
            color = NeonCyan,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        // 1. Language Preferences
        SettingsSection(title = "LANGUAGE PROTOCOL", icon = Icons.Default.Language) {
            val languages = listOf(
                "auto" to "Auto-Detect (বাংলা / English)",
                "bn" to "বাংলা প্রাধান্য (Bangla First)",
                "en" to "English (Sir Default)"
            )

            languages.forEach { (code, label) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            selectedLang = code
                            viewModel.updateLanguage(code)
                        }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedLang == code,
                        onClick = {
                            selectedLang = code
                            viewModel.updateLanguage(code)
                        },
                        colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                    )
                    Text(
                        text = label,
                        color = if (selectedLang == code) NeonCyan else TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = if (selectedLang == code) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // 2. Speech Synthesis (TTS) Controls
        SettingsSection(title = "VOICE ENGINE & SYNTHESIS", icon = Icons.Default.RecordVoiceOver) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Auto-Speak Responses", color = TextPrimary, fontSize = 13.sp)
                    Switch(
                        checked = autoSpeak,
                        onCheckedChange = {
                            autoSpeak = it
                            viewModel.toggleAutoSpeak(it)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = ElectricBlue
                        ),
                        modifier = Modifier.testTag("switch_auto_speak")
                    )
                }

                HorizontalDivider(color = CyberBorder)

                Text(
                    text = "Speech Rate: ${String.format("%.2fx", speechRate)}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Slider(
                    value = speechRate,
                    onValueChange = {
                        speechRate = it
                        viewModel.updateSpeechRate(it)
                    },
                    valueRange = 0.6f..1.6f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonBlue
                    ),
                    modifier = Modifier.testTag("slider_speech_rate")
                )

                Text(
                    text = "Voice Pitch: ${String.format("%.2fx", speechPitch)}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Slider(
                    value = speechPitch,
                    onValueChange = {
                        speechPitch = it
                        viewModel.updateSpeechPitch(it)
                    },
                    valueRange = 0.6f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonBlue
                    ),
                    modifier = Modifier.testTag("slider_speech_pitch")
                )
            }
        }

        // 3. System & Background Assistant
        SettingsSection(title = "SYSTEM & BACKGROUND SERVICE", icon = Icons.Default.Tune) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Foreground Voice Service", color = TextPrimary, fontSize = 13.sp)
                        Text(
                            "Keeps Neo persistent in notification tray for quick access.",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = foregroundService,
                        onCheckedChange = {
                            foregroundService = it
                            viewModel.toggleForegroundService(it)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberGreen,
                            checkedTrackColor = CyberBorder
                        ),
                        modifier = Modifier.testTag("switch_fg_service")
                    )
                }

                HorizontalDivider(color = CyberBorder)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Haptic Feedback on Voice", color = TextPrimary, fontSize = 13.sp)
                    Switch(
                        checked = hapticFeedback,
                        onCheckedChange = {
                            hapticFeedback = it
                            prefs.hapticFeedbackEnabled = it
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = CyberBorder
                        )
                    )
                }
            }
        }

        // 4. Telemetry & Hardware Info
        SettingsSection(title = "DEVICE & NEURAL TELEMETRY", icon = Icons.Default.Info) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                TelemetryRow(label = "ASSISTANT PROTOCOL", value = "NEO JARVIS v3.8")
                TelemetryRow(label = "AI MODEL", value = "Gemini 3.8 Flash (Serverless)")
                TelemetryRow(label = "APP CHECK ATTESTATION", value = "Enforced // Secure")
                TelemetryRow(label = "DEVICE HARDWARE", value = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}")
                TelemetryRow(label = "ANDROID VERSION", value = "API ${Build.VERSION.SDK_INT} (Android ${Build.VERSION.RELEASE})")
                TelemetryRow(label = "STATUS", value = "ALL SUB-SYSTEMS NOMINAL")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsSection(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    }
}
