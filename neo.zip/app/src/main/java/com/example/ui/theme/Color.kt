package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic JARVIS Cyber Theme Palette
val CyberBlack = Color(0xFF030712)
val CyberBackground = Color(0xFF060A14)
val CyberSurface = Color(0xFF0A1224)
val CyberSurfaceVariant = Color(0xFF101C38)
val CyberBorder = Color(0xFF1E3A5F)

val NeonCyan = Color(0xFF00E5FF)
val NeonBlue = Color(0xFF00B0FF)
val ElectricBlue = Color(0xFF2979FF)
val HologramGlow = Color(0xFF80D8FF)

val CyberGreen = Color(0xFF00E676)
val CyberWarning = Color(0xFFFFD600)
val CyberAlert = Color(0xFFFF1744)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextAccent = Color(0xFF38BDF8)
