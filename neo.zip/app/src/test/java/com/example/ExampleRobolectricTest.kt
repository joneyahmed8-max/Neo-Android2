package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun testNeoCoreSanity() {
    val assistantName = "Neo"
    val honorific = "Sir"
    assertEquals("Neo", assistantName)
    assertEquals("Sir", honorific)
  }
}
