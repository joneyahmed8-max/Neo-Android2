package com.example

import com.example.data.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testChatMessageEntity() {
    val message = ChatMessage(
      text = "Turn on flashlight",
      isUser = true,
      language = "en"
    )
    assertTrue(message.isUser)
    assertEquals("en", message.language)
    assertEquals("Turn on flashlight", message.text)
  }

  @Test
  fun testBanglaLanguageDetection() {
    val banglaText = "টর্চ অন করো"
    val hasBangla = banglaText.any { it in '\u0980'..'\u09FF' }
    assertTrue(hasBangla)

    val englishText = "Hello Neo, turn on flashlight"
    val hasNoBangla = englishText.any { it in '\u0980'..'\u09FF' }
    assertFalse(hasNoBangla)
  }
}
